/**
 * index.ts — CaaS Lite platform entry point
 *
 * Wires together: PolicyEngine → VerificationEngine → WebhookReceiver
 * and starts the HTTP server on PORT (default 3000).
 */

import { PolicyEngine } from './engine/policy';
import { VerificationEngine } from './engine/verification';
import { WebhookReceiver } from './webhook/receiver';
import { logger } from './lib/logger';

const PORT = parseInt(process.env['PORT'] ?? '3000', 10);

async function main(): Promise<void> {
  logger.info('caas-lite: starting up');

  const policyEngine = await PolicyEngine.create();
  logger.info('caas-lite: policy engine ready', { policies: policyEngine.size });

  const verificationEngine = new VerificationEngine(policyEngine);

  const receiver = new WebhookReceiver({
    verificationEngine,
    onVerified: async (batch) => {
      // TODO: wire evidenceDb.append() here (Phase 2)
      logger.info('caas-lite: verified batch ready for vault', {
        eventId: batch.event.id,
        outcome: batch.overallOutcome,
        alerts: batch.alerts.length,
      });
    },
  });

  const server = receiver.createServer();
  server.listen(PORT, () => {
    logger.info('caas-lite: webhook receiver listening', { port: PORT });
  });

  process.on('SIGTERM', () => {
    logger.info('caas-lite: SIGTERM received, shutting down');
    server.close(() => process.exit(0));
  });
}

main().catch((e: unknown) => {
  logger.error('caas-lite: fatal startup error', { error: (e as Error).message });
  process.exit(1);
});
